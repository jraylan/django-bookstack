from setuptools import setup

setup(
    data_files=[
        'django_bookstack/templates/django_bookstack/bookstack_wrapper.html',
    ]
)
