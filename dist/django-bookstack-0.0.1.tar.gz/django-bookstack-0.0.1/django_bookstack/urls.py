# -*- coding: utf-8 -*-
from .bookstack import library

urlpatterns = library.get_urls()
